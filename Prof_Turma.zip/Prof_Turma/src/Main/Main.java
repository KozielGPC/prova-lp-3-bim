
package Main;

/**
 *
 * @author radames
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI_Menu gui_menu = new GUI_Menu();
    }
    
}
